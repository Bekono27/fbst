const { test, expect } = require('@playwright/test');

test('seed, rehearse and persist a locally recorded Page', async ({page}) => {
  await page.goto('/');
  await page.getByRole('button',{name:'Load 200 demo drafts'}).click();
  await expect(page.locator('tbody tr')).toHaveCount(200);
  await page.getByLabel('Filter by portfolio').selectOption('Portfolio 1');
  await expect(page.locator('tbody tr')).toHaveCount(50);
  await page.getByRole('button',{name:'Open',exact:true}).first().click();
  page.once('dialog', dialog => dialog.accept());
  await page.getByRole('button',{name:'Rehearse creation'}).click();
  await expect(page.getByText('Rehearsed',{exact:true}).first()).toBeVisible();
  await page.reload();
  await expect(page.locator('tbody')).toContainText('Rehearsed');
});
